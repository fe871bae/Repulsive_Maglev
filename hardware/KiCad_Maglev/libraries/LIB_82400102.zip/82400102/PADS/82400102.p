*PADS-LIBRARY-PART-TYPES-V9*

82400102 SOT95P280X116-6N I DIO 7 1 0 0 0
TIMESTAMP 2026.03.30.14.55.42
"Mouser Part Number" 710-82400102
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/82400102?qs=Wn16VcyqZWq4x2NXBP4V%252Bw%3D%3D
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 82400102
"Description" TVS Diode Array WE-TVS SOT23-6L; 5Vdc; 2pF; 2Channel + VDD; Marking: .W00XY
"Datasheet Link" https://www.we-online.com/catalog/datasheet/82400102.pdf
"Geometry.Height" 1.16mm
GATE 1 6 0
82400102
1 0 U I/O_1_1
2 0 U GND
3 0 U I/O_2_1
6 0 U I/O_1_2
5 0 U VDD
4 0 U I/O_2_2

*END*
*REMARK* SamacSys ECAD Model
267069/2017372/2.50/6/2/Diode
