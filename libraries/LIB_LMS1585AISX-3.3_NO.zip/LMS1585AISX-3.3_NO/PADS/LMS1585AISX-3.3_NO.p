*PADS-LIBRARY-PART-TYPES-V9*

LMS1585AISX-3.3_NO KTT0003B I ANA 6 1 0 0 0
TIMESTAMP 2026.03.28.13.38.32
"Mouser Part Number" 595-LMS1585AISX33/NO
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/LMS1585AISX-3.3-NO?qs=Mv7BduZupUgcTszQb%252BDdgQ%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" LMS1585AISX-3.3/NO
"Description" 5A Fixed / Adjustable Output Linear Regulators / LDO
"Datasheet Link" http://www.ti.com/lit/gpn/LMS1585A
GATE 1 4 0
LMS1585AISX-3.3_NO
1 0 U ADJ/GND
2 0 U OUTPUT
3 0 U INPUT
4 0 U VOUT

*END*
*REMARK* SamacSys ECAD Model
779933/2017372/2.50/4/4/Integrated Circuit
