*PADS-LIBRARY-PART-TYPES-V9*

824011 SOT95P280X116-5N I DIO 7 1 0 0 0
TIMESTAMP 2026.03.28.09.04.17
"Mouser Part Number" 710-824011
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Wurth-Elektronik/824011?qs=Wn16VcyqZWrHR48Vn%2FB8%252Bg%3D%3D
"Manufacturer_Name" Wurth Elektronik
"Manufacturer_Part_Number" 824011
"Description" TVS Diode Array WE-TVS SOT23-5L; 5Vdc; 2pF; 2Channel + VDD; Marking: .W11XY
"Datasheet Link" https://www.we-online.com/catalog/datasheet/824011.pdf
"Geometry.Height" 1.16mm
GATE 1 5 0
824011
1 0 U NC
2 0 G GND
3 0 B I/O1
4 0 B I/O2
5 0 P VDD

*END*
*REMARK* SamacSys ECAD Model
466512/2017372/2.50/5/2/Diode
