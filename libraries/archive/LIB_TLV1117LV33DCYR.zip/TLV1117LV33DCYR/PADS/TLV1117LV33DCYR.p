*PADS-LIBRARY-PART-TYPES-V9*

TLV1117LV33DCYR SOT230P700X180-4N I ANA 7 1 0 0 0
TIMESTAMP 2026.03.28.13.45.46
"Mouser Part Number" 595-TLV1117LV33DCYR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/TLV1117LV33DCYR?qs=tEz3BkPb1rwzXMb8FiWhow%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" TLV1117LV33DCYR
"Description" 1-A, Positive Fixed Voltage, Low-Dropout Regulator
"Datasheet Link" http://www.ti.com/lit/gpn/tlv1117lv
"Geometry.Height" 1.8mm
GATE 1 4 0
TLV1117LV33DCYR
1 0 U GND
2 0 U OUTPUT_1
3 0 U INPUT
4 0 U OUTPUT_2

*END*
*REMARK* SamacSys ECAD Model
326441/2017372/2.50/4/3/Integrated Circuit
